import numpy as np

mag=np.linspace(0,10,10)
print(mag)
