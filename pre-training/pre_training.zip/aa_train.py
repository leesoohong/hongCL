import os
import torch
import random
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from controller import Controller
from augement_policy2 import Policy2
from config import *
from aa_utils import *
import time
from functools import partial
from itertools import product

import re
import sys
import argparse
from utils import logger
from res_gcn import ResGCN
from datasets import get_dataset
from train_eval import controller_train, cross_validation_with_val_set, single_train_test
from utils import logger
DATA_SOCIAL = ['COLLAB', 'IMDB-BINARY', 'IMDB-MULTI']
DATA_SOCIAL += ['REDDIT-MULTI-5K', 'REDDIT-MULTI-12K', 'REDDIT-BINARY']
DATA_BIO = ['MUTAG', 'NCI1', 'PROTEINS', 'DD', 'ENZYMES', 'PTC_MR']
DATA_REDDIT = [
    data for data in DATA_BIO + DATA_SOCIAL if "REDDIT" in data]
DATA_NOREDDIT = [
    data for data in DATA_BIO + DATA_SOCIAL if "REDDIT" not in data]
DATA_SUBSET_STUDY = ['COLLAB', 'IMDB-BINARY', 'IMDB-MULTI',
                     'NCI1', 'PROTEINS', 'DD']
DATA_SUBSET_STUDY_SUP = [
    d for d in DATA_SOCIAL + DATA_BIO if d not in DATA_SUBSET_STUDY]
DATA_SUBSET_FAST = ['IMDB-BINARY', 'PROTEINS', 'IMDB-MULTI', 'ENZYMES']
DATA_IMAGES = ['MNIST', 'MNIST_SUPERPIXEL', 'CIFAR10']


str2bool = lambda x: x.lower() == "true"
parser = argparse.ArgumentParser()
parser.add_argument('--exp', type=str, default="benchmark")
parser.add_argument('--data_root', type=str, default="/home/hong/CL/pre-training/data")
parser.add_argument('--epochs', type=int, default=100)
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--lr', type=float, default=0.001)
parser.add_argument('--lr_decay_factor', type=float, default=0.5)
parser.add_argument('--lr_decay_step_size', type=int, default=500)
parser.add_argument('--epoch_select', type=str, default='test_max')
parser.add_argument('--n_layers_feat', type=int, default=1)
parser.add_argument('--n_layers_conv', type=int, default=3)
parser.add_argument('--n_layers_fc', type=int, default=2)
parser.add_argument('--hidden', type=int, default=128)
parser.add_argument('--global_pool', type=str, default="sum")
parser.add_argument('--skip_connection', type=str2bool, default=False)
parser.add_argument('--res_branch', type=str, default="BNConvReLU")
parser.add_argument('--dropout', type=float, default=0)
parser.add_argument('--edge_norm', type=str2bool, default=True)
parser.add_argument('--with_eval_mode', type=str2bool, default=True)
parser.add_argument('--dataset', type=str, default="NCI1")
parser.add_argument('--aug1', type=str, default="dropN")
parser.add_argument('--aug_ratio1', type=float, default=0.2)
parser.add_argument('--aug2', type=str, default="maskN")
parser.add_argument('--aug_ratio2', type=float, default=0.2)
parser.add_argument('--suffix', type=int, default=0)

# autoaugment
parser.add_argument('--layers', type=int, default=40)
parser.add_argument('--widening_factor', type=int, default=2)
parser.add_argument('--aa_dropout', type=float, default=0.3)
parser.add_argument('--cnn_train_epochs', type=int, default=3)    # 120
parser.add_argument('--cnn_lr', type=float, default=0.025)
parser.add_argument('--cnn_weight_decay', type=float, default=3e-4)
# dataset
parser.add_argument('--data_dir', type=str, default='/home/hong/CL/Auto-Augment/data')
parser.add_argument('--aa_batch_size', type=int, default=128)

# search space
# parser.add_argument('--augment_types', type=list, default=['dropN','maskN','perm_E','subgraph'
# 										])
# parser.add_argument('--magnitude_types', type=list, default=range(10))
parser.add_argument('--augment_types', type=list, default=["dropN",
            "maskN",
            "permE",
            "subgraph"])
parser.add_argument('--magnitude_types', type=list, default=range(10))
parser.add_argument('--prob_types', type=list, default=range(11))
parser.add_argument('--op_num_pre_subpolicy', type=int, default=2)
parser.add_argument('--subpolicy_num', type=int, default=5)

# controller
parser.add_argument('--controller_hid_size', type=int, default=100)
parser.add_argument('--controller_lr', type=float, default=3.5e-4)
parser.add_argument('--softmax_temperature', type=float, default=5.)
parser.add_argument('--tanh_c', type=float, default=2.5)
parser.add_argument('--entropy_coeff', type=float, default=1e-5)
parser.add_argument('--baseline_decay', type=float, default=0.95)
parser.add_argument('--controller_grad_clip', type=float, default=0.)

# training
parser.add_argument('--cuda', type=bool, default=True)
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--seed', type=int, default=2)
parser.add_argument('--mode', type=str, default='train')
parser.add_argument('--search_epochs', type=int, default=1500)  # 1500
args = parser.parse_args()


def get_model_with_default_configs(model_name,
                                   num_feat_layers=args.n_layers_feat,
                                   num_conv_layers=args.n_layers_conv,
                                   num_fc_layers=args.n_layers_fc,
                                   residual=args.skip_connection,
                                   hidden=args.hidden):
    # More default settings.
    res_branch = args.res_branch
    global_pool = args.global_pool
    dropout = args.dropout
    edge_norm = args.edge_norm

    # modify default architecture when needed
    if model_name.find('_') > 0:
        num_conv_layers_ = re.findall('_conv(\d+)', model_name)
        if len(num_conv_layers_) == 1:
            num_conv_layers = int(num_conv_layers_[0])
            print('[INFO] num_conv_layers set to {} as in {}'.format(
                num_conv_layers, model_name))
        num_fc_layers_ = re.findall('_fc(\d+)', model_name)
        if len(num_fc_layers_) == 1:
            num_fc_layers = int(num_fc_layers_[0])
            print('[INFO] num_fc_layers set to {} as in {}'.format(
                num_fc_layers, model_name))
        residual_ = re.findall('_res(\d+)', model_name)
        if len(residual_) == 1:
            residual = bool(int(residual_[0]))
            print('[INFO] residual set to {} as in {}'.format(
                residual, model_name))
        gating = re.findall('_gating', model_name)
        if len(gating) == 1:
            global_pool += "_gating"
            print('[INFO] add gating to global_pool {} as in {}'.format(
                global_pool, model_name))
        dropout_ = re.findall('_drop([\.\d]+)', model_name)
        if len(dropout_) == 1:
            dropout = float(dropout_[0])
            print('[INFO] dropout set to {} as in {}'.format(
                dropout, model_name))
        hidden_ = re.findall('_dim(\d+)', model_name)
        if len(hidden_) == 1:
            hidden = int(hidden_[0])
            print('[INFO] hidden set to {} as in {}'.format(
                hidden, model_name))



    if model_name.startswith('ResGFN'):
        collapse = True if 'flat' in model_name else False
        def foo(dataset):
            return ResGCN(dataset, hidden, num_feat_layers, num_conv_layers,
                          num_fc_layers, gfn=True, collapse=collapse,
                          residual=residual, res_branch=res_branch,
                          global_pool=global_pool, dropout=dropout,
                          edge_norm=edge_norm)
    elif model_name.startswith('ResGCN'):
        def foo(dataset):
            return ResGCN(dataset, hidden, num_feat_layers, num_conv_layers,
                          num_fc_layers, gfn=False, collapse=False,
                          residual=residual, res_branch=res_branch,
                          global_pool=global_pool, dropout=dropout,
                          edge_norm=edge_norm)
    else:
        raise ValueError("Unknown model {}".format(model_name))
    return foo


def validate(val_data, len_val, device, model):
	model.eval()
	val_loss = 0.0
	val_top1 = AvgrageMeter()
	val_top5 = AvgrageMeter()
	criterion = nn.CrossEntropyLoss().to(device)

	with torch.no_grad():
		for step, (inputs, targets) in enumerate(val_data):
			inputs, targets = inputs.to(device), targets.to(device)
			outputs = model(inputs)
			loss = criterion(outputs, targets)
			val_loss += loss.item()
			prec1, prec5 = accuracy(outputs, targets, topk=(1, 5))
			n = inputs.size(0)
			val_top1.update(prec1.item(), n)
			val_top5.update(prec5.item(), n)

	return val_top1.avg, val_top5.avg, val_loss / (step + 1)


def train_cnn(args, model, device, train_quene, len_train, val_quene, len_val):
	optimizer = torch.optim.SGD(model.parameters(), lr=args.cnn_lr, momentum=0.9, weight_decay=args.cnn_weight_decay)
	scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, args.cnn_train_epochs, eta_min=1e-8)
	best_val_acc = 0.
	
	for e in range(args.cnn_train_epochs):
		model.train()
		scheduler.step()
		
		t1 = time.time()
		train_loss, top1, top5 = 0.0, AvgrageMeter(), AvgrageMeter()
		criterion = nn.CrossEntropyLoss().to(device)
		for step, (inputs, targets) in enumerate(train_quene):
			inputs, targets = inputs.to(device), targets.to(device)
			
			optimizer.zero_grad()
			outputs = model(inputs)
			loss = criterion(outputs, targets)
			loss.backward()
			
			# nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
			prec1, prec5 = accuracy(outputs, targets, topk=(1, 5))
			n = inputs.size(0)
			top1.update(prec1.item(), n)
			top5.update(prec5.item(), n)
			
			optimizer.step()
			train_loss += loss.item()
			
			print('\rEpoch: {}/{}, step: {}/{}, train loss: {:.6}, top1: {:.4}, top5: {:.4}'.format(
					e + 1, args.cnn_train_epochs, step + 1, len_train, loss, top1.avg, top5.avg), end='')
		val_acc, _, _ = validate(val_quene, len_val, device, model)
		if val_acc > best_val_acc:
			best_val_acc= val_acc
		t2 = time.time()
		print('\nval acc of this epoch: {:.4}, best val acc: {:.4}, time: {:.4}/s'.format(val_acc, best_val_acc, t2-t1))
	return best_val_acc


def train_controller(args, controller, optimizer, val_acc, baseline):
	controller.train()
	
	entropies, log_prob = controller.entropies, controller.log_probs
	# entropies, log_prob = torch.Tensor(np.array(entropies)).cuda(), torch.Tensor(np.array(log_prob)).cuda()
	# np_entropies = entropies.data.cpu().numpy()
	reward = val_acc + args.entropy_coeff * entropies
	
	if baseline is None:
		baseline = reward
	else:
		decay = args.baseline_decay
		baseline = decay * baseline + (1 - decay) * reward
		baseline = baseline.clone().detach()
	
	adv = reward - baseline
	# loss = -log_prob * get_variable(adv, args.cuda, requires_grad=False)
	loss = -log_prob * adv
	loss -= args.entropy_coeff * entropies
	loss = loss.sum()
	
	optimizer.zero_grad()
	loss.backward()
	
	if args.controller_grad_clip > 0:
		torch.nn.utils.clip_grad_norm(controller.parameters(), args.controller_grad_clip)
	optimizer.step()
	
	print('entropies: {}, log_prob: {}, reward: {}, loss: {}'.format(entropies.item(), log_prob.item(), reward, loss))
	
args = parser.parse_args()
os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)

if torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")
cudnn.benchmark = True
torch.manual_seed(args.seed)
cudnn.enabled = True
torch.cuda.manual_seed(args.seed)

# controller
controller = Controller(args).to(device)
controller_optimizer = torch.optim.SGD(controller.parameters(), args.controller_lr, momentum=0.9)
baseline = None

# searchw 
for epoch in range(1000):
	print('-'*50)
	print('{} th search'.format(epoch + 1))
	print('-'*50)
	
	# sample subpolicy
	print('*'*30)
	print('sample subpolicy')
	print('*'*30)
	controller.eval()
	policy_dict = controller.sample()
	policy_provider = Policy2(args, policy_dict)
	for p in policy_dict:
		valueList = list(p[0].values())
		print(p)
		print(valueList[0])
	policy_idx = random.randint(0, len(policy_dict) - 1)
	print(policy_dict[policy_idx][0])
	a=list(policy_dict[policy_idx][0].values())
	b=list(policy_dict[policy_idx][1].values())
	mag=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
	a[1]=mag[a[1]]
	b[1]=mag[b[1]]
	print(a[0])
	print(a[1])
	get_model=get_model_with_default_configs
	results = []
	dataset_feat_net_triples=[('NCI1', 'deg+odeg100+ak3+reall', 'ResGCN')]
	exp_nums = len(dataset_feat_net_triples)
	print("-----\nTotal %d experiments in this run:" % exp_nums)
	for exp_id, (dataset_name, feat_str, net) in enumerate(
			dataset_feat_net_triples):
		print('{}/{} - {} - {} - {}'.format(
			exp_id+1, exp_nums, dataset_name, feat_str, net))
	print("Here we go..")
	sys.stdout.flush()
	for exp_id, (dataset_name, feat_str, net) in enumerate(
			dataset_feat_net_triples):
		print('-----\n{}/{} - {} - {} - {}'.format(
			exp_id+1, exp_nums, dataset_name, feat_str, net))
		sys.stdout.flush()
		dataset = get_dataset(
			dataset_name, sparse=True, feat_str=feat_str, root=args.data_root)
		model_func = get_model(net)
		print(dataset)
		
	val_acc = controller_train(
				dataset,
				model_func,
				folds=10,
				epochs=100,
				batch_size=128,
				lr=0.01,
				lr_decay_factor=0.5,
				lr_decay_step_size=0.5,
				weight_decay=0,
				epoch_select=500,
				with_eval_mode=True,
				logger=logger,
				dataset_name=args.dataset,
					aug1=a[0], aug_ratio1=a[1],
								aug2=b[0], aug_ratio2=b[1], suffix=None)
	

	
	# train cnn
	print('*' * 30)
	print('train cnn')
	print('*' * 30)
	

	print(val_acc)
	
	# train controller
	print('*' * 30)
	print('train controller')
	print('*' * 30)
	train_controller(args, controller, controller_optimizer, val_acc, baseline)
	
	# save
	state = {
		'args': args,
		'best_acc': val_acc,
		'controller_state': controller.state_dict(),
		'policy_dict': policy_dict
	}
	if epoch==100:
    	 torch.save(state, '/home/hong/CL/pre-training/aa_models/{}.pt.tar'.format(epoch))
	



	









