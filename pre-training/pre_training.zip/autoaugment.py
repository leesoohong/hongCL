import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from tu_dataset import get_transformations, magnitude
LSTM_UNITS = 100
SUBPOLICIES = 5
SUBPOLICY_OPS = 2

OP_TYPES = 4
OP_MAGNITUDES = 9
transformations = get_transformations()

class Subpolicy:
    def __init__(self, *operations):
        self.operations = operations

    def __call__(self, X):
        for op in self.operations:
            X = op(X)
        return X

    def __str__(self):
        ret = ''
        for i, op in enumerate(self.operations):
            ret += str(op)
            if i < len(self.operations)-1:
                ret += '\n'
        return ret

class Operation:
    def __init__(self, types_softmax, magnitudes_softmax, argmax=False):
        # Ekin Dogus says he sampled the softmaxes, and has not used argmax
        # We might still want to use argmax=True for the last predictions, to ensure
        # the best solutions are chosen and make it deterministic.
        a=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
        if argmax:
            self.type = types_softmax.argmax()
            t = transformations[self.type]
            m = magnitudes_softmax.argmax()
            self.magnitude=magnitude[m]
        else:
            self.type = np.random.choice(OP_TYPES, p=types_softmax)
            t = transformations[self.type]
            m = magnitudes_softmax.argmax()

            self.magnitude = np.random.choice(a, p=magnitudes_softmax)
        self.transformation = t

    def __call__(self, X):
        _X = []
        for x in X:
            if np.random.rand() < self.prob:
                x = PIL.Image.fromarray(x)
                x = self.transformation(x, self.magnitude)
            _X.append(np.array(x))
        return np.array(_X)

    def __str__(self):
        return 'Operation %2d (P=%.3f, M=%.3f)' % (self.type, self.prob, self.magnitude)


SUBPOLICY_OPS=2
subpolicies=5

class Controller(nn.Module):
     def __init__(self):

        super(Controller, self).__init__()
        self.num_layers=1
        self.hidden_size=100
        # self.input_layer=nn.Linear(5*1,100)
        self.lstm = nn.LSTM(input_size=(1), hidden_size=100,num_layers=self.num_layers)
        self.fc1=nn.Linear(100,4)
        self.fc2=nn.Linear(100,9)

      #   self.W = nn.Parameter(torch.randn([100, 4]))
      #   self.b = nn.Parameter(torch.randn([4]))
      #   self.W2 = nn.Parameter(torch.randn([100, 9]))
      #   self.b2 = nn.Parameter(torch.randn([9]))

        self.Softmax = nn.Softmax(dim=1)
        
     def forward(self,X):
        outputs = []
        for i in range(2):
           h_0 = Variable(torch.zeros(self.num_layers, 5, 100))
           c_0 = Variable(torch.zeros(self.num_layers, 5, 100))

           output,(hn,cn)= self.lstm(X,(h_0,c_0))
           hn = hn.view(-1, self.hidden_size)
           out1=self.fc1(hn)
           out2=self.fc2(hn)
           out1=self.Softmax(out1)
           out2=self.Softmax(out2)
           outputs+=[out1,out2]

        return outputs

     def fit(self,mem_sofmaxes,mem_accuracies):
        min_acc=np.min(mem_accuracies)
        max_acc=np.max(mem_accuracies)
        dummy_input=np.zeros((1,5,1))
        dummy_input=torch.from_numpy(dummy_input)
        for softmaxes, acc in zip(mem_softmaxes, mem_accuracies):
                scale = (acc-min_acc) / (max_acc-min_acc)
                dict_outputs = {_output: s for _output, s in zip(self.model.outputs, softmaxes)}
                dict_scales = {self.scale: scale}
                session.run(self.optimizer, feed_dict={**dict_outputs, **dict_scales, **dict_input})
        return self

     def predict(self, size):
        dummy_input=torch.zeros((1,5,1))
        softmaxes = model((dummy_input))
        # convert softmaxes into subpolicies
        subpolicies = []
        for i in range(SUBPOLICIES):
            operations = []
            for j in range(2):
                op = softmaxes[j*2:(j+1)*2]
                op[0]=op[0].detach().numpy()
                op[1]=op[1].detach().numpy()
                op = [o[i, :] for o in op]
                operations.append(Operation(*op))
                subpolicies.append(Subpolicy(*operations))

        return softmaxes,subpolicies
   
OP_MAGNITUDES = 9
mem_softmaxes = []
mem_accuracies = []

model = Controller()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

softmaxes, subpolicies = model.predict(5)

# for epoch in range(100):
#     print('Controller: Epoch %d / %d' % (epoch+1, 100))

#     softmaxes, subpolicies = model.predict(SUBPOLICIES)
#     for i, subpolicy in enumerate(subpolicies):
#         print('# Sub-policy %d' % (i+1))
#         print(subpolicy)
#     mem_softmaxes.append(softmaxes)

#     child = Child(Xtr.shape[1:])
#     tic = time.time()
#     child.fit(subpolicies, Xtr, ytr)
#     toc = time.time()
#     accuracy = child.evaluate(Xts, yts)
#     print('-> Child accuracy: %.3f (elaspsed time: %ds)' % (accuracy, (toc-tic)))
#     mem_accuracies.append(accuracy)

#     if len(mem_softmaxes) > 5:
#         # ricardo: I let some epochs pass, so that the normalization is more robust
#         controller.fit(mem_softmaxes, mem_accuracies)
#     print()