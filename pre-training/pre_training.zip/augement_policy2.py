from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import random


class Policy2(object):
	""" Randomly choose one of the best 24 Sub-policies on ImageNet.
	
	    Example:
	        policy = ImageNetPolicy()
	        transformed = policy(image)
	
	    Example as a PyTorch Transform:
	        transform = transforms.Compose([
	            transforms.Resize(256),
	            ImageNetPolicy(),
	            transforms.ToTensor()])
	"""

	def __init__(self, args, searched_policies):
		probs = np.linspace(0., 1.0, 11)
		self.policies = []
		for i in range(args.subpolicy_num):
			prob_1, prob_2 = probs[searched_policies[i][0]['prob']], probs[searched_policies[i][1]['prob']]
			op_1, op_2 = searched_policies[i][0]['op'], searched_policies[i][1]['op']
			magnitude_1, magnitude_2 = searched_policies[i][0]['magnitude'], searched_policies[i][1]['magnitude']
			
			self.policies.append((prob_1, op_1, magnitude_1, prob_2, op_2, magnitude_2))
		

	def __call__(self, img):
		policy_idx = random.randint(0, len(self.policies) - 1)
		return self.policies[policy_idx](img)

	def __repr__(self):
		return "AutoAugment ImageNet Policy"


class SubPolicy(object):
	def __init__(self,
                 p1,
                 operation1,
                 magnitude_idx1,
                 p2,
                 operation2,
                 magnitude_idx2,
                 fillcolor=(128, 128, 128)):
		ranges = {
            "dropN",
            "maskN",
            "permE",
            "subgraph"}

		# from https://stackoverflow.com/questions/5252170/specify-image
		# -filling-color-when-rotating-in-python-with-pil-and-setting-expand

		func = {
            "dropN": lambda img, magnitude: img.transform(
                img.size,
                Image.AFFINE,
                (1, magnitude * random.choice([-1, 1]), 0, 0, 1, 0),
                Image.BICUBIC,
                fillcolor=fillcolor),
                
        }

		# self.name = "{}_{:.2f}_and_{}_{:.2f}".format(
		#     operation1, ranges[operation1][magnitude_idx1],
		#     operation2, ranges[operation2][magnitude_idx2])
		self.p1 = p1
		self.operation1 = func[operation1]
		self.magnitude1 = ranges[operation1][magnitude_idx1]
		self.p2 = p2
		self.operation2 = func[operation2]
		self.magnitude2 = ranges[operation2][magnitude_idx2]

	def __call__(self, img):
		if random.random() < self.p1:
			img = self.operation1(img, self.magnitude1)
		if random.random() < self.p2:
			img = self.operation2(img, self.magnitude2)
		return img









