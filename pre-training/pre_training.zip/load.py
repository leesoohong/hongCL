import os
import torch
import random
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from controller import Controller
from augement_policy2 import Policy2
from config import *
from aa_utils import *
import time
from functools import partial
from itertools import product

import re

model=torch.load('/home/hong/CL/pre-training/aa_models/0.pt.tar')
print(model)